// class AppLifecycleManager {
//   static final AppLifecycleManager _instance = AppLifecycleManager._internal();
//   factory AppLifecycleManager() => _instance;
//   AppLifecycleManager._internal();

//   bool _isExiting = false;

//   bool get isExiting => _isExiting;
//   set isExiting(bool value) => _isExiting = value;
// }
