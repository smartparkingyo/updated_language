import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:parking_app/constants.dart';
import 'package:parking_app/services/notification_service.dart';
import 'package:location/location.dart';
import 'package:flutter_map/flutter_map.dart'; // Ensure Polygon is imported from here
import 'location_monitor.dart';
import 'polygon_helper.dart';

class LocationProvider extends ChangeNotifier {
  Position _currentLocation = Position(
    longitude: 75.780411,
    latitude: 11.258753,
    timestamp: DateTime.now(),
    accuracy: 0,
    altitude: 0,
    altitudeAccuracy: 0,
    heading: 0,
    headingAccuracy: 0,
    speed: 0,
    speedAccuracy: 0,
  );
  bool _serviceEnabled = true;
  LocationMonitor? _locationMonitor;
  Location location = Location();
  List<Polygon> polygons = PolygonHelper.createPolygons();

  bool get serviceEnabled => _serviceEnabled;

  LocationProvider(BuildContext context) {
    _locationMonitor = LocationMonitor(
      context: context,
      polygons: polygons,
      location: location,
    );
    determinePosition();
  }

  Future<void> determinePosition() async {
    bool serviceEnabled;
    PermissionStatus permission;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      _serviceEnabled = false;
      notifyListeners();
      Fluttertoast.showToast(
        msg: "Location services are disabled.",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.TOP,
        timeInSecForIosWeb: 1,
        backgroundColor: backgroundColor,
        textColor: Colors.white,
        fontSize: 16.0,
      );
      return Future.error('Location services are disabled.');
    }

    permission = await location.hasPermission();
    if (permission == PermissionStatus.denied) {
      permission = await location.requestPermission();
      if (permission == PermissionStatus.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == PermissionStatus.deniedForever) {
      return Future.error('Location permissions are permanently denied');
    }

    _serviceEnabled = true;
    notifyListeners();
    LocationData? locationData = await location.getLocation();
    if (locationData != null) {
      _currentLocation = Position(
        longitude: locationData.longitude!,
        latitude: locationData.latitude!,
        timestamp: DateTime.now(),
        accuracy: 0,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: locationData.speed ?? 0,
        speedAccuracy: 0,
      );
    }
    print(_currentLocation.latitude);
    notifyListeners();

    location.onLocationChanged.listen((LocationData locationData) {
      _currentLocation = Position(
        longitude: locationData.longitude!,
        latitude: locationData.latitude!,
        timestamp: DateTime.now(),
        accuracy: 0,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: locationData.speed ?? 0,
        speedAccuracy: 0,
      );
      _locationMonitor?.currentLocation = locationData;
      notifyListeners();
    });
  }

  Position get currentLocation => _currentLocation;

  @override
  void dispose() {
    _locationMonitor?.dispose();
    super.dispose();
  }
}
