import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class PolygonHelper {
  // Define your polygons here
  static final List<List<LatLng>> _polygonPoints = [
    [
      LatLng(11.321699492577258, 75.93347316054869),
      LatLng(11.321791340091805, 75.93357321748574),
      LatLng(11.321567983584648, 75.9338414552319),
      LatLng(11.321474048552945, 75.93372862506882),
    ],
    [
      LatLng(11.321284090950146, 75.93380313555387),
      LatLng(11.321373851151792, 75.93388190378091),
      LatLng(11.321332102224295, 75.93391170797494),
      LatLng(11.321263216480615, 75.93384571297389),
    ],
  ];

  static List<Polygon> createPolygons() {
    return _polygonPoints.map((points) => Polygon(
      points: points,
      borderColor: Colors.red,
      borderStrokeWidth: 3,
      color: Color.fromARGB(255, 234, 105, 105).withOpacity(0.2),
    )).toList();
  }

  static bool isPointInPolygon(LatLng point, List<LatLng> polygon) {
    int n = polygon.length;
    bool inside = false;

    double px = point.latitude;
    double py = point.longitude;

    double p1x = polygon[0].latitude;
    double p1y = polygon[0].longitude;
    for (int i = 1; i <= n; i++) {
      double p2x = polygon[i % n].latitude;
      double p2y = polygon[i % n].longitude;
      if (py > p1y && py <= p2y || py > p2y && py <= p1y) {
        if (px <= (p2x - p1x) * (py - p1y) / (p2y - p1y) + p1x) {
          inside = !inside;
        }
      }
      p1x = p2x;
      p1y = p2y;
    }

    return inside;
  }
}
