// // lib/screens/dummy_ev_parking_screen.dart
// import 'package:flutter/material.dart';

// class DummyEVParkingScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Nearby EV Parking Spots'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           children: [
//             // List of EV Charging Spots
//             Expanded(
//               child: ListView(
//                 children: [
//                   ListTile(
//                     title: Text('TATA'),
//                     subtitle: Text('2 charging points are free'),
//                   ),
//                   ListTile(
//                     title: Text('Aether'),
//                     subtitle: Text('No charging point available for the time being'),
//                   ),
//                   // Add more items as needed
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
